# Repository context

Connectors and checkouts supply current repository files. SOURCE.md identifies the exported snapshot. Use the revision specified by the task.

Keep this repository's environment and existing entry points.

<!-- export-project:v1 -->
~~~json
{"version":1,"writing_profile":"default-micro","files":[]}
~~~
